import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import db from "./db.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// GET all notes
app.get("/notes", async (req, res) => {
    const [rows] = await db.query("SELECT * FROM notes ORDER BY id DESC");
    res.json(rows);
});

// CREATE note
app.post("/notes", async (req, res) => {
    const { title, body } = req.body;
    await db.query("INSERT INTO notes (title, body) VALUES (?, ?)", [title, body]);
    res.json({ message: "Note added" });
});

// UPDATE note
app.put("/notes/:id", async (req, res) => {
    const { id } = req.params;
    const { title, body } = req.body;
    await db.query("UPDATE notes SET title=?, body=? WHERE id=?", [
        title,
        body,
        id,
    ]);
    res.json({ message: "Note updated" });
});

// DELETE note
app.delete("/notes/:id", async (req, res) => {
    const { id } = req.params;
    await db.query("DELETE FROM notes WHERE id=?", [id]);
    res.json({ message: "Note deleted" });
});

app.listen(5000, () => console.log("Server running on port 5000"));
