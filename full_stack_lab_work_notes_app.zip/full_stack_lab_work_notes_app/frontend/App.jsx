import { BrowserRouter, Routes, Route } from "react-router-dom";
import NotesList from "./components/NotesList";
import NoteForm from "./components/NoteForm";
import EditNote from "./components/EditNote";

function App() {
  return (
    <BrowserRouter>
      <div className="container">
        <h1>Notes Management App</h1>

        <Routes>
          <Route path="/" element={<NotesList />} />
          <Route path="/add" element={<NoteForm />} />
          <Route path="/edit/:id" element={<EditNote />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
