import { useParams, useNavigate } from "react-router-dom";
import { useNotes } from "../context/NotesContext";
import { useState, useEffect } from "react";

export default function EditNote() {
  const { id } = useParams();
  const { notes, updateNote } = useNotes();
  const navigate = useNavigate();

  const [note, setNote] = useState({ title: "", body: "" });

  useEffect(() => {
    const existing = notes.find((n) => n.id == id);
    if (existing) setNote(existing);
  }, [notes]);

  const handleSubmit = (e) => {
    e.preventDefault();
    updateNote(id, note);
    navigate("/");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        value={note.title}
        onChange={(e) => setNote({ ...note, title: e.target.value })}
      />
      <textarea
        value={note.body}
        onChange={(e) => setNote({ ...note, body: e.target.value })}
      ></textarea>

      <button type="submit">Save</button>
    </form>
  );
}
