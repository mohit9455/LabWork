import { Link } from "react-router-dom";
import { useNotes } from "../context/NotesContext";

export default function NotesList() {
  const { notes, deleteNote } = useNotes();

  return (
    <div>
      <Link to="/add">
        <button>Add Note</button>
      </Link>

      {notes.map((note) => (
        <div key={note.id} className="note">
          <h3>{note.title}</h3>
          <p>{note.body}</p>

          <Link to={`/edit/${note.id}`}>
            <button>Edit</button>
          </Link>

          <button onClick={() => deleteNote(note.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}
