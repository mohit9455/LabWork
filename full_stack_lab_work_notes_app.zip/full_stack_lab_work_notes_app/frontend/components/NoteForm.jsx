import { useState } from "react";
import { useNotes } from "../context/NotesContext";
import { useNavigate } from "react-router-dom";

export default function NoteForm() {
  const [note, setNote] = useState({ title: "", body: "" });
  const { addNote } = useNotes();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    addNote(note);
    navigate("/");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Title"
        value={note.title}
        onChange={(e) => setNote({ ...note, title: e.target.value })}
      />
      <textarea
        placeholder="Body"
        value={note.body}
        onChange={(e) => setNote({ ...note, body: e.target.value })}
      ></textarea>

      <button type="submit">Add</button>
    </form>
  );
}
