import { createContext, useContext, useEffect, useState } from "react";
import axios from "axios";

const NotesContext = createContext();
export const useNotes = () => useContext(NotesContext);

export const NotesProvider = ({ children }) => {
  const [notes, setNotes] = useState([]);
  const API = "http://localhost:5000/api/notes";

  // Fetch all notes
  const getNotes = async () => {
    const res = await axios.get(API);
    setNotes(res.data);
  };

  // Add
  const addNote = async (note) => {
    await axios.post(API, note);
    getNotes();
  };

  // Update
  const updateNote = async (id, note) => {
    await axios.put(`${API}/${id}`, note);
    getNotes();
  };

  // Delete
  const deleteNote = async (id) => {
    await axios.delete(`${API}/${id}`);
    getNotes();
  };

  useEffect(() => {
    getNotes();
  }, []);

  return (
    <NotesContext.Provider value={{ notes, addNote, updateNote, deleteNote }}>
      {children}
    </NotesContext.Provider>
  );
};
